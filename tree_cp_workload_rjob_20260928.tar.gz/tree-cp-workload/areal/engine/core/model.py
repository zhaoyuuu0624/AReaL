# SPDX-License-Identifier: Apache-2.0

from enum import Enum
from importlib.metadata import PackageNotFoundError, version

import torch
from packaging.version import InvalidVersion, Version

VALID_VISION_MODELS = [
    "qwen2_vl",
    "qwen2_5_vl",
    "qwen3_vl",
    "qwen3_vl_moe",
    "qwen3_5",
    "qwen3_5_moe",
    "gemma3",
]
# This registry is used to check if a model is a vision model that we have checked it works with AReaL.
# As different vision models vary in their image processing, special tokens and keys, etc.
# We will add models to this registry as we test them.
# If you want to add a new vision model, please make sure it works with AReaL.


def is_valid_vision_model(model_type: str) -> bool:
    return model_type in VALID_VISION_MODELS


def is_qwen2_vl_model(model_type: str) -> bool:
    return model_type in ["qwen2_vl", "qwen2_5_vl"]


def is_qwen3_vl_model(model_type: str) -> bool:
    """True for the Qwen3-VL family (dense and MoE).

    Existing call sites in ``fsdp_engine``, ``fsdp_utils/parallel``, and
    ``awex/fsdp_adapter`` gate family-level behaviour (mRoPE index,
    attention-mask handling) that is identical for dense and MoE, so this
    helper covers both. Use ``is_qwen3_vl_moe_model`` when the MoE-vs-dense
    distinction matters.
    """
    return model_type in ("qwen3_vl", "qwen3_vl_moe")


def is_qwen3_vl_moe_model(model_type: str) -> bool:
    return model_type == "qwen3_vl_moe"


def is_qwen_vl_model(model_type: str) -> bool:
    return is_qwen2_vl_model(model_type) or is_qwen3_vl_model(model_type)


def lang_config(hf_config):
    """Return the language-model side of a (possibly nested) HF config.

    Qwen3-VL and similar VLMs nest text-model attributes (vocab_size,
    num_attention_heads, num_key_value_heads, hidden_size, head_dim) under
    ``hf_config.text_config``. Qwen2.5-VL and pure text models keep them
    flat. Use this anywhere the caller wants a language-side attribute and
    doesn't know the model family up front.
    """
    return getattr(hf_config, "text_config", hf_config)


def is_gemma3_model(model_type: str) -> bool:
    return model_type in ["gemma3"]


VALID_MOE_MODELS = [
    "qwen3_moe",
    "qwen3_vl_moe",
    "qwen3_5_moe",
    "qwen3_5_moe_text",
    "bailing_moe_v2",
    "bailing_moe_linear",
    "bailing_hybrid",
]
# This registry is used to check if a model is a MoE model that we have checked it works with AReaL.


def is_moe_model(model_type: str) -> bool:
    return model_type in VALID_MOE_MODELS


def is_qwen3_moe_model(model_type: str) -> bool:
    return model_type in ["qwen3_moe"]


def is_qwen3_5_model(model_type: str) -> bool:
    return model_type in ["qwen3_5", "qwen3_5_text", "qwen3_5_moe", "qwen3_5_moe_text"]


class SequencePackingMode(str, Enum):
    WRAPPER_THD = "wrapper_thd"
    MODEL_THD = "model_thd"
    PADDED = "padded"


def supports_gdn_packed_seq() -> bool:
    """Require the released GDN THD/CP kernel and matching Qwen bridge."""
    try:
        return Version(version("megatron-core")) >= Version("0.18.2") and Version(
            version("megatron-bridge")
        ) >= Version("0.5.1")
    except PackageNotFoundError:
        return False


def validate_model_packed_seq_dependencies(
    model_type: str, bridge_type: str, context_parallel_size: int
) -> None:
    """Validate dependencies required by model-owned Qwen VLM THD paths."""
    requires_new_stack = bridge_type == "megatron-bridge" and (
        model_type in ("qwen3_5", "qwen3_5_moe")
        or (is_qwen3_vl_model(model_type) and context_parallel_size > 1)
    )
    if not requires_new_stack:
        return

    minimum_versions = {
        "megatron-core": Version("0.18.2"),
        "megatron-bridge": Version("0.5.1"),
    }
    found_versions: dict[str, str] = {}
    incompatible = False
    for package, minimum in minimum_versions.items():
        try:
            raw_version = version(package)
            found_versions[package] = raw_version
            incompatible |= Version(raw_version) < minimum
        except PackageNotFoundError:
            found_versions[package] = "not installed"
            incompatible = True
        except InvalidVersion:
            found_versions[package] = f"invalid version {raw_version!r}"
            incompatible = True

    if incompatible:
        found = ", ".join(
            f"{package}={found_versions[package]}" for package in minimum_versions
        )
        raise RuntimeError(
            "Model-owned THD requires megatron-core>=0.18.2 and "
            "megatron-bridge>=0.5.1 for "
            f"model_type={model_type}, bridge_type={bridge_type}, "
            f"context_parallel_size={context_parallel_size}; found {found}. "
            "Upgrade the Megatron runtime image before enabling this path."
        )


def supports_model_packed_seq(model_type: str, bridge_type: str) -> bool:
    """Whether the bridge model owns BSHD-to-THD packing internally."""
    return bridge_type == "megatron-bridge" and (
        is_qwen3_vl_model(model_type) or model_type in ("qwen3_5", "qwen3_5_moe")
    )


def resolve_sequence_packing_mode(
    model_type: str, bridge_type: str
) -> SequencePackingMode:
    """Select one packing path from the model and bridge contract."""
    if supports_model_packed_seq(model_type, bridge_type):
        return SequencePackingMode.MODEL_THD
    if is_valid_vision_model(model_type) or requires_padded_seq(
        model_type, bridge_type
    ):
        return SequencePackingMode.PADDED
    return SequencePackingMode.WRAPPER_THD


def requires_padded_seq(model_type: str, bridge_type: str | None = None) -> bool:
    """Whether the model must run the padded (BSHD) forward instead of packed (THD).

    Only the active Megatron-Bridge backend has a validated GDN THD contract.
    Keep other or unspecified bridges padded regardless of installed packages.
    """
    return is_qwen3_5_model(model_type) and not (
        bridge_type == "megatron-bridge" and supports_gdn_packed_seq()
    )


# Copied from trl
def disable_dropout_in_model(model: torch.nn.Module) -> None:
    for module in model.modules():
        if isinstance(module, torch.nn.Dropout):
            module.p = 0
