# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

import aiohttp
import httpx
import openai

from areal.api.workflow_api import RolloutWorkflow
from areal.infra import workflow_context
from areal.infra.rpc.rtensor import RTensor
from areal.infra.rpc.serialization import deserialize_value
from areal.infra.utils.http import async_http_retry
from areal.utils import logging, stats_tracker

if TYPE_CHECKING:
    from areal.api.engine_api import InferenceEngine
    from areal.experimental.openai.types import InteractionWithTokenLogpReward
    from areal.v2.inference_service.controller.controller import (
        RolloutControllerV2,
    )

logger = logging.getLogger("InferenceServiceWorkflow")

_RL_START_SESSION_PATHNAME = "rl/start_session"
_RL_SET_REWARD_PATHNAME = "rl/set_reward"
_EXPORT_TRAJECTORIES_PATHNAME = "export_trajectories"

_CONNECTION_ERROR_TYPES: tuple[type[BaseException], ...] = (
    httpx.ConnectError,
    httpx.RemoteProtocolError,
    httpx.ReadError,
    aiohttp.ClientConnectorError,
    aiohttp.ServerDisconnectedError,
    ConnectionRefusedError,
    ConnectionResetError,
    OSError,
    openai.APIConnectionError,
)


class InferenceServiceWorkflow(RolloutWorkflow):
    def __init__(
        self,
        controller: RolloutControllerV2,
        agent: Any | None = None,
        gateway_addr: str = "",
        admin_api_key: str = "areal-admin-key",
        discount: float = 1.0,
        export_style: str = "individual",
        timeout: float | None = None,
        group_size: int = 1,
        serialize_group_samples: bool = False,
        drop_retry_orphans: bool = False,
        reward_normalization: bool = False,
        drop_incomplete_group: bool = False,
        min_usable_group_size: int = 1,
    ):
        self.controller = controller
        self.agent = agent
        self.gateway_addr = gateway_addr.rstrip("/") if gateway_addr else ""
        self._admin_api_key = admin_api_key
        self.discount = discount
        self.export_style = export_style
        self.timeout = timeout
        self.group_size = group_size
        self.serialize_group_samples = serialize_group_samples
        self.drop_retry_orphans = drop_retry_orphans
        self.reward_normalization = reward_normalization
        self.drop_incomplete_group = drop_incomplete_group
        self.min_usable_group_size = min_usable_group_size

    @async_http_retry
    async def _start_session(
        self,
        session: aiohttp.ClientSession,
        task_id: str,
        group_size: int = 1,
    ) -> tuple[str | None, list[tuple[str, str]]]:
        """Start one or more sessions. Returns (group_id, [(session_id, api_key), ...])."""
        url = f"{self.gateway_addr}/{_RL_START_SESSION_PATHNAME}"
        headers = {"Authorization": f"Bearer {self._admin_api_key}"}
        payload: dict[str, Any] = {"task_id": task_id, "group_size": group_size}
        async with session.post(url, json=payload, headers=headers) as resp:
            resp.raise_for_status()
            data = await resp.json()
        group_id = data.get("group_id")
        credentials = [
            (s["session_id"], s["session_api_key"]) for s in data["sessions"]
        ]
        return group_id, credentials

    @async_http_retry
    async def _set_last_reward(
        self,
        session: aiohttp.ClientSession,
        reward: float,
        session_api_key: str,
        rewards: dict[str, float] | None = None,
    ) -> int | None:
        """Report the trajectory reward.

        ``rewards`` optionally carries the per-interaction breakdown, applied
        server-side in a single request so the trajectory is finalized once.
        """
        url = f"{self.gateway_addr}/{_RL_SET_REWARD_PATHNAME}"
        headers = {"Authorization": f"Bearer {session_api_key}"}
        payload: dict[str, Any] = {
            "interaction_id": None,
            "reward": reward,
        }
        if rewards is not None:
            payload["rewards"] = rewards
        async with session.post(url, json=payload, headers=headers) as resp:
            resp.raise_for_status()
            data = await resp.json()
        trajectory_id = data.get("trajectory_id")
        return int(trajectory_id) if trajectory_id is not None else None

    async def _export_interactions(
        self,
        session: aiohttp.ClientSession,
        session_ids: list[str],
        group_id: str | None = None,
        trajectory_id: int | None = None,
        discard_trajectory: bool = False,
        remove_session: bool = True,
        export_session_ids: list[str] | None = None,
        min_usable_group_size: int = 1,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "session_ids": session_ids,
            "group_id": group_id,
            "trajectory_id": trajectory_id,
            "discount": self.discount,
            "style": self.export_style,
            "remove_session": remove_session,
            "drop_retry_orphans": self.drop_retry_orphans,
            "reward_normalization": self.reward_normalization,
            "discard_trajectory": discard_trajectory,
            "is_eval": workflow_context.get().is_eval,
            "min_usable_group_size": min_usable_group_size,
        }
        if export_session_ids is not None:
            payload["export_session_ids"] = export_session_ids
        data = await self._request_export(session, payload)
        traj = deserialize_value(data["traj"])
        if data.get("prm_stats") is not None:
            from pydantic import TypeAdapter

            from areal.reward.prm.export import PRMExportStats

            stats = TypeAdapter(PRMExportStats).validate_python(data["prm_stats"])
            # Outside the HTTP retry boundary, and before the empty-trajectory
            # check: these are scoring observations, not training acceptance stats.
            stats.record(is_eval=payload["is_eval"])
        return traj

    @async_http_retry
    async def _request_export(
        self, session: aiohttp.ClientSession, payload: dict[str, Any]
    ) -> dict[str, Any]:
        url = f"{self.gateway_addr}/{_EXPORT_TRAJECTORIES_PATHNAME}"
        headers = {"Authorization": f"Bearer {self._admin_api_key}"}
        async with session.post(url, json=payload, headers=headers) as resp:
            resp.raise_for_status()
            return await resp.json()

    async def arun_episode(
        self,
        engine: InferenceEngine,
        data: dict[str, Any],
    ) -> dict[str, InteractionWithTokenLogpReward] | None:
        del engine
        http_session = await workflow_context.get_aiohttp_session()

        if self.agent is not None:
            return await self._run_offline(http_session, data)
        return await self._run_online(http_session)

    async def _run_offline(
        self,
        http_session: aiohttp.ClientSession,
        data: dict[str, Any],
    ) -> dict[str, InteractionWithTokenLogpReward] | None:
        task_id = workflow_context.get().task_id
        group_id, sessions = await self._start_session(
            http_session, str(task_id), group_size=self.group_size
        )
        execution_mode = "serial" if self.serialize_group_samples else "concurrent"
        version = self.controller.get_version()
        logger.info(
            "V2 rollout group dispatch: task_id=%s group_id=%s version=%s "
            "group_size=%d mode=%s sessions=%s",
            task_id,
            group_id,
            version,
            len(sessions),
            execution_mode,
            [session_id for session_id, _ in sessions],
        )

        assert self.agent is not None
        http_client = await workflow_context.get_httpx_client()

        async def _run_one(
            member_index: int,
            session_id: str,
            session_api_key: str,
        ) -> float | None:
            """Run one agent session. Returns reward on success, ``None`` on failure."""
            logger.debug(
                "V2 rollout member start: task_id=%s group_id=%s member=%d "
                "session_id=%s version=%s mode=%s",
                task_id,
                group_id,
                member_index,
                session_id,
                version,
                execution_mode,
            )
            try:
                rewards = await self.agent.run(
                    data,
                    base_url=self.gateway_addr,
                    http_client=http_client,
                    api_key=session_api_key,
                )
                step_rewards: dict[str, float] | None = None
                if isinstance(rewards, dict):
                    if rewards:
                        step_rewards = {str(k): float(v) for k, v in rewards.items()}
                        final_reward = float(next(reversed(rewards.values())))
                    else:
                        final_reward = 0.0
                elif isinstance(rewards, (int, float)):
                    final_reward = float(rewards)
                else:
                    raise ValueError(f"Invalid reward type: {type(rewards)}")

                await self._set_last_reward(
                    http_session,
                    final_reward,
                    session_api_key,
                    rewards=step_rewards,
                )
                return final_reward
            except Exception as exc:
                is_conn_err = isinstance(exc, _CONNECTION_ERROR_TYPES) or (
                    exc.__cause__ is not None
                    and isinstance(exc.__cause__, _CONNECTION_ERROR_TYPES)
                )
                if is_conn_err:
                    logger.warning(
                        "Agent task failed (%s). Trajectory rejected (connection lost).",
                        type(exc).__name__,
                    )
                else:
                    logger.warning(
                        "Agent task failed (%s: %s). This trajectory will be rejected.",
                        type(exc).__name__,
                        exc,
                        exc_info=True,
                    )
                # Failed members are excluded from training below, so a fallback
                # reward is unnecessary and can trigger another round of HTTP
                # retries. Group export still handles session cleanup.
                return None
            finally:
                logger.debug(
                    "V2 rollout member finish: task_id=%s group_id=%s member=%d "
                    "session_id=%s version=%s mode=%s",
                    task_id,
                    group_id,
                    member_index,
                    session_id,
                    version,
                    execution_mode,
                )

        if self.serialize_group_samples:
            results = []
            for member_index, (session_id, session_api_key) in enumerate(sessions):
                results.append(
                    await _run_one(member_index, session_id, session_api_key)
                )
        else:
            results = await asyncio.gather(
                *[
                    _run_one(member_index, session_id, session_api_key)
                    for member_index, (session_id, session_api_key) in enumerate(
                        sessions
                    )
                ]
            )

        session_ids = [sid for sid, _ in sessions]
        successful_session_ids = [
            session_id
            for session_id, result in zip(session_ids, results)
            if result is not None
        ]
        n_succeeded = len(successful_session_ids)
        n_failed = len(sessions) - n_succeeded
        discard_group = n_failed > 0 and self.drop_incomplete_group
        discard_group = discard_group or n_succeeded < self.min_usable_group_size

        # Always export to trigger session cleanup on the data proxy,
        # even when we intend to discard the trajectories.
        export_kwargs: dict[str, Any] = {
            "group_id": group_id,
            "discard_trajectory": discard_group,
        }
        if not discard_group and len(sessions) > 1:
            export_kwargs["export_session_ids"] = successful_session_ids
            export_kwargs["min_usable_group_size"] = (
                len(sessions)
                if self.drop_incomplete_group
                else self.min_usable_group_size
            )
        traj = await self._export_interactions(
            http_session,
            session_ids,
            **export_kwargs,
        )
        if discard_group:
            logger.warning(
                "Abandoning group %s: %d/%d sessions succeeded "
                "(drop_incomplete_group=%s, min_usable_group_size=%d)",
                group_id,
                n_succeeded,
                len(sessions),
                self.drop_incomplete_group,
                self.min_usable_group_size,
            )
            return None
        if n_failed > 0:
            logger.warning(
                "Using partial group %s: %d/%d sessions succeeded",
                group_id,
                n_succeeded,
                len(sessions),
            )
        if not traj:
            return None

        tracker = stats_tracker.get(workflow_context.stat_scope())
        for r in results:
            if r is not None:
                tracker.scalar(reward=r)

        return traj

    async def _run_online(
        self,
        http_session: aiohttp.ClientSession,
    ) -> dict[str, InteractionWithTokenLogpReward] | None:
        logger.debug("Waiting for next ready online trajectory")
        export_request = await self.controller.wait_for_online_trajectory(
            timeout=self.timeout
        )
        if not export_request:
            return None

        session_id = export_request["session_id"]
        traj = await self._export_interactions(
            http_session,
            [session_id],
            trajectory_id=export_request["trajectory_id"],
            # The persistent HITL session may receive its next trajectory while
            # this export awaits scoring. Ordinary session-key exports still end
            # their session so that the key can be refreshed.
            remove_session=session_id != "__hitl__",
        )
        if not traj:
            return None

        rewards_tensor = traj.get("rewards")
        if isinstance(rewards_tensor, RTensor):
            rewards_tensor = rewards_tensor.to_local()

        if rewards_tensor is not None and len(rewards_tensor) > 0:
            last_reward = float(rewards_tensor[-1])
        elif (
            "interactions" in traj
            and traj["interactions"]
            and traj["interactions"][-1].get("reward") is not None
        ):
            last_reward = float(traj["interactions"][-1]["reward"])
        else:
            logger.warning(
                "Exported trajectory is missing rewards. This trajectory will be rejected."
            )
            return None

        stats_tracker.get(workflow_context.stat_scope()).scalar(reward=last_reward)
        return traj
